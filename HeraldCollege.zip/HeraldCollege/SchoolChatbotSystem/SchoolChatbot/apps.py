from django.apps import AppConfig


class StudentManagementAppConfig(AppConfig):
    name = 'SchoolChatbot'
